function _1(md){return(
md`# IV Proj
Vinay Kumar (vk2771), Antar Espadas Rodríguez (ae3144), Dharun Ramesh (dr4075)

`
)}

function _d3(require){return(
require("d3@7")
)}

function _topojson(require){return(
require("topojson-client@3")
)}

function _4(FileAttachment){return(
FileAttachment("Nutrition__Physical_Activity__and_Obesity_-_Behavioral_Risk_Factor_Surveillance_System.csv").csv()
)}

function _obesityData(FileAttachment){return(
FileAttachment("Nutrition__Physical_Activity__and_Obesity_-_Behavioral_Risk_Factor_Surveillance_System.csv").csv()
)}

async function _6(obesityData){return(
(await obesityData).slice(0,5)
)}

function _7(FileAttachment){return(
FileAttachment("Air_Quality.csv").csv()
)}

function _airData(FileAttachment){return(
FileAttachment("Air_Quality.csv").csv({typed: true})
)}

async function _9(airData){return(
(await airData).slice(0,5)
)}

function _us(d3){return(
d3.json("https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json")
)}

function _11(topojson,us){return(
topojson.feature(us, us.objects.states).features.slice(0,5)
)}

function _12(md){return(
md`Prepare filtered + summarized data`
)}

async function _stateData(obesityData,d3)
{
  const data = await obesityData;

  // Filter to relevant rows (obesity or physical activity) with numeric values
  const filtered = data.filter(d =>
    d.Topic &&
    (d.Topic.toLowerCase().includes("obesity") ||
     d.Topic.toLowerCase().includes("physical activity")) &&
    d.Data_Value
  );

  // Normalize topic names to simple labels
  const grouped = d3.rollups(
    filtered,
    v => d3.mean(v, d => +d.Data_Value),
    d => d.LocationAbbr,
    d => +d.YearStart,
    d => {
      const topic = d.Topic.toLowerCase();
      if (topic.includes("obesity")) return "obesity";
      if (topic.includes("physical activity")) return "physical_activity";
      return "other";
    }
  );

  // Restructure into nested object
  const result = {};
  for (const [state, years] of grouped) {
    result[state] = {};
    for (const [year, topics] of years) {
      result[state][year] = Object.fromEntries(topics);
    }
  }
  return result;
}


function _stateFIPS(){return(
new Map([
  ["01","AL"],["02","AK"],["04","AZ"],["05","AR"],["06","CA"],["08","CO"],["09","CT"],
  ["10","DE"],["11","DC"],["12","FL"],["13","GA"],["15","HI"],["16","ID"],["17","IL"],
  ["18","IN"],["19","IA"],["20","KS"],["21","KY"],["22","LA"],["23","ME"],["24","MD"],
  ["25","MA"],["26","MI"],["27","MN"],["28","MS"],["29","MO"],["30","MT"],["31","NE"],
  ["32","NV"],["33","NH"],["34","NJ"],["35","NM"],["36","NY"],["37","NC"],["38","ND"],
  ["39","OH"],["40","OK"],["41","OR"],["42","PA"],["44","RI"],["45","SC"],["46","SD"],
  ["47","TN"],["48","TX"],["49","UT"],["50","VT"],["51","VA"],["53","WA"],["54","WV"],
  ["55","WI"],["56","WY"]
])
)}

function _15(stateData){return(
Object.keys(stateData).slice(0,10)
)}

function _16(stateData){return(
Object.keys(stateData).slice(0,10)
)}

function _17(stateData){return(
Object.keys(stateData["AL"])
)}

function _18(stateData){return(
stateData["AL"][2020]
)}

function _19(md){return(
md`### Question 1

**How have obesity and physical activity rates varied geographically across U.S. states over time?**

This visualization shows how obesity and physical activity rates differ across the United States, and how these rates have changed from year to year. Each state is colored by its average reported rate for the selected metric (obesity or physical activity).\`
`
)}

function _colorScale(d3,stateData){return(
d3.scaleSequential()
  .domain(d3.extent(
    Object.values(stateData).flatMap(d => Object.values(d).flatMap(e => Object.values(e)))
  ))
  .interpolator(d3.interpolateYlOrRd)
)}

function _legend(d3,colorScale)
{
  const width = 300;
  const height = 50;

  const canvas = d3.create("canvas")
    .attr("width", width)
    .attr("height", height);

  const context = canvas.node().getContext("2d");

  const image = context.createImageData(width, 1);
  for (let i = 0; i < width; ++i) {
    const t = i / (width - 1);
    const c = d3.rgb(colorScale(colorScale.domain()[0] + t * (colorScale.domain()[1] - colorScale.domain()[0])));
    image.data[i * 4 + 0] = c.r;
    image.data[i * 4 + 1] = c.g;
    image.data[i * 4 + 2] = c.b;
    image.data[i * 4 + 3] = 255;
  }
  context.putImageData(image, 0, 0);

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height + 40);

  const defs = svg.append("defs");
  defs.append(() => canvas.node());

  svg.append("image")
    .attr("xlink:href", canvas.node().toDataURL())
    .attr("width", width)
    .attr("height", height);

  const axisScale = d3.scaleLinear()
    .domain(colorScale.domain())
    .range([0, width]);

  const axis = d3.axisBottom(axisScale)
    .ticks(5)
    .tickSize(6);

  svg.append("g")
    .attr("transform", `translate(0,${height})`)
    .call(axis)
    .call(g => g.append("text")
      .attr("x", width / 2)
      .attr("y", 30)
      .attr("fill", "currentColor")
      .attr("text-anchor", "middle")
      .text("% Rate"));

  return svg.node();
}


function _tooltip()
{
  const div = document.createElement("div");
  div.style.position = "absolute";
  div.style.visibility = "hidden";
  div.style.background = "#fff";
  div.style.padding = "4px 8px";
  div.style.border = "1px solid #999";
  div.style.borderRadius = "4px";
  div.style.font = "12px sans-serif";
  div.style.pointerEvents = "none"; // important so it doesn't block mouse
  div.style.zIndex = 10;
  document.body.appendChild(div);
  return div;
}


function _year(html)
{
  const input = html`<input type="range" min=2011 max=2022 step=1 value=2022>`;
  input.addEventListener("input", () => input.dispatchEvent(new CustomEvent("input")));
  return input;
}


function _metric(html)
{
  const select = html`
    <select>
      <option value="obesity">Obesity</option>
      <option value="physical_activity">Physical Activity</option>
    </select>
  `;
  select.addEventListener("input", () => select.dispatchEvent(new CustomEvent("input")));
  return select;
}


function _map(d3,metric,year,stateData,topojson,us,stateFIPS,tooltip)
{
  const width = 960, height = 600;

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)
    .style("background", "#f8f8f8");

  // --- Dynamic title ---
  const titleText = metric === "obesity"
    ? `Obesity Rates Across U.S. States (${year})`
    : `Physical Activity Rates Across U.S. States (${year})`;

  svg.append("text")
    .attr("x", width/2)
    .attr("y", 30)
    .attr("text-anchor", "middle")
    .attr("font-size", "20px")
    .attr("font-weight", "bold")
    .attr("fill", "#333")
    .text(titleText);

  // --- Color scale ---
  const allValues = Object.values(stateData)
    .flatMap(d => Object.values(d).flatMap(e => Object.values(e)));
  const colorScale = d3.scaleSequential()
    .domain(d3.extent(allValues))
    .interpolator(d3.interpolateYlOrRd);

  // --- Legend ---
  const legendWidth = 260, legendHeight = 10;
  const legendX = d3.scaleLinear().domain(colorScale.domain()).range([0, legendWidth]);
  const legendGroup = svg.append("g")
    .attr("transform", `translate(${width/2 - legendWidth/2}, ${height - 40})`);

  const defs = svg.append("defs");
  const linearGradient = defs.append("linearGradient").attr("id", "legend-gradient");
  linearGradient.selectAll("stop")
    .data(d3.range(0, 1.01, 0.01))
    .join("stop")
    .attr("offset", d => `${d*100}%`)
    .attr("stop-color", d => colorScale(colorScale.domain()[0] + d*(colorScale.domain()[1]-colorScale.domain()[0])));

  legendGroup.append("rect")
    .attr("width", legendWidth)
    .attr("height", legendHeight)
    .style("fill", "url(#legend-gradient)")
    .attr("stroke", "#999")
    .attr("rx", 3);

  const legendAxis = d3.axisBottom(legendX).ticks(5).tickFormat(d => d.toFixed(1));
  legendGroup.append("g")
    .attr("transform", `translate(0,${legendHeight})`)
    .call(legendAxis)
    .call(g => g.select(".domain").remove());
  legendGroup.append("text")
    .attr("x", legendWidth/2)
    .attr("y", -6)
    .attr("text-anchor", "middle")
    .attr("fill", "black")
    .attr("font-size", "12px")
    .text("% Rate");

  // --- Projection & path ---
  const projection = d3.geoAlbersUsa().scale(1000).translate([480, 300]);
  const path = d3.geoPath(projection);
  const states = topojson.feature(us, us.objects.states).features;

  // --- Draw states ---
  svg.selectAll("path.state")
    .data(states)
    .join("path")
    .attr("class", "state")
    .attr("d", path)
    .attr("fill", d => {
      const abbr = stateFIPS.get(d.id);
      const val = stateData[abbr]?.[year]?.[metric];
      return val? colorScale(val) : "#eee";
    })
    .attr("stroke", "#999")
    .style("pointer-events", "all")
    .on("mouseover", (event, d) => {
      const abbr = stateFIPS.get(d.id);
      const val = stateData[abbr]?.[year]?.[metric];
      tooltip.style.visibility = "visible";
      tooltip.textContent = `${abbr}: ${val ? val.toFixed(1)+"%" : "No data"}`;
    })
    .on("mousemove", event => {
      tooltip.style.top = `${event.pageY - 20}px`;
      tooltip.style.left = `${event.pageX + 10}px`;
    })
    .on("mouseout", () => {
      tooltip.style.visibility = "hidden";
    });

  return svg.node();
}


function _26(md){return(
md`The geographic variation in U.S. obesity rates has remained largely consistent over time, with a pervasive trend of increasing rates across nearly all states from 2011 to 2022. While specific data on physical activity rates over that period wasn't provided, it's generally understood that low physical activity correlates with high obesity.

The core geographical pattern shows a pronounced split between the South and Midwest regions, which consistently exhibit the highest obesity rates, and the West and Northeast regions, which tend to have the lowest rates.

**Obesity Rate Trends (2011 vs. 2022)**

The comparison between the 2011 and 2022 maps (indicated by the darker shading in the 2022 image) and supporting data reveals a significant increase in obesity prevalence:

Overall Increase: The number of states with high obesity rates has drastically increased. A decade ago (around 2011-2012), no state had an adult obesity rate at or above 35%. By 2022, 22 states had adult obesity rates at or above 35%.

Highest Rate States: States in the South and lower Midwest have consistently had the highest rates. Historically, states like Mississippi, West Virginia, and Arkansas have been among the most affected, often exceeding 35% in recent years.

Lowest Rate States: States in the West, particularly Colorado and the District of Columbia/Hawaii, have maintained the lowest obesity rates over the period, often remaining below the 25% threshold. Colorado has the unique distinction of often having the lowest rate in the country.

**Key Geographic Patterns**

The maps and general trends highlight several key geographic disparities:

Southern and Midwestern Concentration: The states with the deepest red/orange coloring, indicating the highest obesity rates, are clustered in the South (e.g., Louisiana, Alabama, Mississippi) and the Midwest (e.g., Indiana, Ohio, Iowa).

Western/Mountain States Exception: States in the Mountain West (like Colorado) and the Northeast (less visible on the provided maps, but generally lower) form a noticeable contrast, with lighter colors indicating lower obesity rates.

Physical Activity Implication: Since physical inactivity is a major contributing factor to obesity, it can be inferred that the states with the highest obesity rates (South/Midwest) also have, on average, lower rates of physical activity compared to states with the lowest obesity rates (West/Northeast).

Overall, the geographical distribution of high obesity rates—clustered primarily in the Southern and Midwestern US—is a persistent trend, but the magnitude of the problem has grown significantly nationwide between 2011 and 2022.`
)}

function _27(md){return(
md`### Question 2:

**What are the temporal trends in air quality measures (e.g., PM2.5 levels) across different regions?**`
)}

function _airQuality(FileAttachment){return(
FileAttachment("Air_Quality.csv").csv({ typed: true })
)}

function _airQualityData(d3,airQuality){return(
d3.rollups(
  airQuality,
  v => d3.mean(v, d => +d["Data Value"]),
  d => d["Geo Place Name"],
  d => +d["Time Period"]
)
.map(([region, values]) => ({
  region,
  values: values
    .filter(([year, val]) => year && val)
    .map(([year, val]) => ({ year, value: val }))
    .sort((a, b) => a.year - b.year)
}))
)}

function _region(html,airQualityData)
{
  const select = html`<select></select>`;
  for (const r of airQualityData.map(d => d.region)) {
    const opt = document.createElement("option");
    opt.value = r;
    opt.textContent = r;
    select.appendChild(opt);
  }
  return select;
}


function _lineChart(d3,airQualityData,region)
{
  const margin = { top: 50, right: 40, bottom: 50, left: 70 };
  const width = 800, height = 400;
  
  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)
    .style("background", "#fafafa");

  const data = airQualityData.find(d => d.region === region)?.values || [];

  // --- Scales ---
  const x = d3.scaleLinear()
    .domain(d3.extent(data, d => d.year))
    .range([margin.left, width - margin.right]);

  const y = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.value)]).nice()
    .range([height - margin.bottom, margin.top]);

  // --- Gridlines ---
  const yGrid = d3.axisLeft(y)
    .tickSize(-width + margin.left + margin.right)
    .tickFormat("");

  svg.append("g")
    .attr("class", "grid")
    .attr("transform", `translate(${margin.left},0)`)
    .call(yGrid)
    .selectAll("line")
    .attr("stroke", "#ddd");

  // --- Line generator ---
  const line = d3.line()
    .x(d => x(d.year))
    .y(d => y(d.value))
    .curve(d3.curveMonotoneX);

  // --- Draw line ---
  svg.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "#1f77b4")
    .attr("stroke-width", 2.5)
    .attr("d", line);

  // --- Axes ---
  const xAxis = d3.axisBottom(x).tickFormat(d3.format("d"));
  const yAxis = d3.axisLeft(y);

  svg.append("g")
    .attr("transform", `translate(0,${height - margin.bottom})`)
    .call(xAxis);

  svg.append("g")
    .attr("transform", `translate(${margin.left},0)`)
    .call(yAxis);

  // --- Axis labels ---
  svg.append("text")
    .attr("x", width / 2)
    .attr("y", height - 10)
    .attr("text-anchor", "middle")
    .attr("font-size", "12px")
    .text("Year");

  svg.append("text")
    .attr("x", -height / 2)
    .attr("y", 15)
    .attr("transform", "rotate(-90)")
    .attr("text-anchor", "middle")
    .attr("font-size", "12px")
    .text("PM2.5 (µg/m³)");

  // --- Title ---
  svg.append("text")
    .attr("x", width / 2)
    .attr("y", margin.top - 25)
    .attr("text-anchor", "middle")
    .attr("font-size", "16px")
    .attr("font-weight", "bold")
    .text(`PM2.5 Levels Over Time — ${region}`);

  return svg.node();
}


function _32(md){return(
md`The temporal trends in PM2.5 levels across different New York City regions exhibit a striking, synchronized pattern, suggesting that major, city-wide factors primarily drive air quality changes. The data consistently shows four distinct phases across all boroughs examined: an initial period of rising levels peaking around 2010; a dramatic and swift decline between 2010 and 2012, which represents the most significant improvement; a volatile phase from approximately 2012 to 2016 characterized by sharp, successive peaks and troughs; and finally, a consistent, gradual increase in PM2.5 levels from 2016 through 2019. This suggests a major policy intervention or economic shift occurred around 2011, causing the large initial drop, with subsequent years reflecting a combination of continued regulatory effects, weather patterns, and regional-specific emission sources.

While the overall trend is uniform, there is a substantial geographical disparity in the magnitude of the pollution. Manhattan consistently shows the highest PM2.5 levels, often reaching peaks of around 85−90 μg/m 
3
  in the early years and exhibiting the most extreme volatility in subsequent years. This high magnitude likely reflects the concentration of traffic, building density, and energy use in the city's commercial and residential core. Conversely, Staten Island maintains the lowest PM2.5 levels, peaking at only about 15 μg/m 
3
 , and displays the least volatile trend, indicative of generally superior air quality due to its lower population density and different land-use characteristics. The Bronx, Brooklyn, and the NYC overall average fall into a mid-range, peaking around 40 μg/m 
3
  and displaying volatility similar in shape but lower in magnitude compared to Manhattan. The fact that all regions, including the cleanest, show the same post-2016 upward trajectory suggests a common, city-wide pressure is causing a recent deterioration in air quality.`
)}

function _33(md){return(
md`### Question 3:

**Are there visible correlations between poor air quality and lower physical activity levels across New York?**`
)}

function _34(airQualityData){return(
airQualityData.slice(0, 5)
)}

function _35(obesityData){return(
obesityData.slice(0, 5)
)}

function _36(airQualityData){return(
airQualityData[0]
)}

async function _regressionLinear(require){return(
(await require("d3-regression@1")).regressionLinear
)}

function _38(regressionLinear){return(
typeof regressionLinear
)}

function _region1(Inputs,airQualityData){return(
Inputs.select(
  Array.from(new Set(airQualityData.map(d => d.region))).sort(),
  { label: "Select Region", value: "Flushing and Whitestone (CD7)" }
)
)}

function _scatterPlot(airQualityData,region1,obesityData,d3,tooltip)
{
  const width = 700, height = 450;
  const margin = { top: 50, right: 30, bottom: 60, left: 70 };

  // --- Filter data ---
  const air = airQualityData.find(d => d.region === region1)?.values || [];
  const pa = obesityData.filter(d =>
    d.LocationDesc === "New York" &&
    d.Topic.toLowerCase().includes("physical activity")
  );

  // --- Combine by year ---
  const combined = air.map(a => {
    const year = +a.year;
    const activity = pa.find(p => +p.YearStart === year)?.Data_Value;
    return { year, pm25: +a.value, activity: +activity };
  }).filter(d => d.pm25 && d.activity);

  // --- Scales ---
  const x = d3.scaleLinear()
    .domain([d3.min(combined, d => d.pm25) - 1, d3.max(combined, d => d.pm25) + 1])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleLinear()
    .domain([d3.min(combined, d => d.activity) - 2, d3.max(combined, d => d.activity) + 2])
    .range([height - margin.bottom, margin.top]);

  // --- SVG setup ---
  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)
    .style("background", "#fafafa");

  // --- Axes ---
  svg.append("g")
    .attr("transform", `translate(0,${height - margin.bottom})`)
    .call(d3.axisBottom(x))
    .append("text")
    .attr("x", width / 2)
    .attr("y", 40)
    .attr("fill", "#000")
    .attr("text-anchor", "middle")
    .text("PM2.5 (µg/m³)");

  svg.append("g")
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(y))
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("x", -height / 2)
    .attr("y", -45)
    .attr("fill", "#000")
    .attr("text-anchor", "middle")
    .text("Physical Activity Rate (%)");

  // --- Scatter points ---
  svg.selectAll("circle")
    .data(combined)
    .join("circle")
    .attr("cx", d => x(d.pm25))
    .attr("cy", d => y(d.activity))
    .attr("r", 5)
    .attr("fill", "#1f77b4")
    .attr("opacity", 0.8)
    .on("mouseover", (event, d) => {
      tooltip.style.visibility = "visible";
      tooltip.textContent = `${d.year}: PM2.5 = ${d.pm25.toFixed(1)}, Activity = ${d.activity.toFixed(1)}%`;
    })
    .on("mousemove", event => {
      tooltip.style.top = `${event.pageY - 20}px`;
      tooltip.style.left = `${event.pageX + 10}px`;
    })
    .on("mouseout", () => tooltip.style.visibility = "hidden");

  // --- Regression + correlation ---
  if (combined.length > 1) {
    const n = combined.length;
    const meanX = d3.mean(combined, d => d.pm25);
    const meanY = d3.mean(combined, d => d.activity);

    const slope = d3.sum(combined, d => (d.pm25 - meanX) * (d.activity - meanY)) /
                  d3.sum(combined, d => Math.pow(d.pm25 - meanX, 2));
    const intercept = meanY - slope * meanX;

    const xVals = d3.extent(combined, d => d.pm25);
    const regLineData = xVals.map(xVal => [xVal, slope * xVal + intercept]);

    const line = d3.line()
      .x(d => x(d[0]))
      .y(d => y(d[1]));

    svg.append("path")
      .datum(regLineData)
      .attr("fill", "none")
      .attr("stroke", "red")
      .attr("stroke-width", 2)
      .attr("d", line);

    // --- Compute correlation coefficient (r) ---
    const numerator = d3.sum(combined, d => (d.pm25 - meanX) * (d.activity - meanY));
    const denominator = Math.sqrt(
      d3.sum(combined, d => Math.pow(d.pm25 - meanX, 2)) *
      d3.sum(combined, d => Math.pow(d.activity - meanY, 2))
    );
    const r = numerator / denominator;

    // --- Add correlation text ---
    svg.append("text")
      .attr("x", width - 150)
      .attr("y", margin.top)
      .attr("text-anchor", "start")
      .attr("font-size", "14px")
      .attr("fill", "darkred")
      .text(`r = ${r.toFixed(2)}`);
  }

  // --- Title ---
  svg.append("text")
    .attr("x", width / 2)
    .attr("y", margin.top - 20)
    .attr("text-anchor", "middle")
    .attr("font-size", "16px")
    .attr("font-weight", "bold")
    .attr("fill", "#333")
    .text(`Correlation Between Air Quality (PM2.5) and Physical Activity — ${region1}`);

  return svg.node();
}


function _41(md){return(
md`The correlation coefficient, r=0.44, indicates a moderately positive linear relationship between the two variables.

**Interpretation of the Correlation**

The scatter plot visualizes the relationship between PM2.5 levels (μg/m3) on the X-axis and the Physical Activity Rate (%) on the Y-axis.

Positive Correlation (r>0): The red regression line slopes upward from left to right. This means that as PM2.5 levels increase (worse air quality), the physical activity rate also tends to increase.

Magnitude (r=0.44): A value of 0.44 suggests a moderate link. While the data points generally follow the upward trend line, they are also quite scattered, indicating that PM2.5 is not the only or the strongest factor determining the physical activity rate. Other variables, like economic status, urban planning, or cultural factors, are likely more influential.

Context: This finding is counter-intuitive to what might be expected, as poor air quality is generally known to discourage outdoor physical activity due to health risks.

**Potential Explanations for the Counter-Intuitive Trend**

The positive correlation suggests that areas or time periods with higher PM2.5 levels (often Manhattan, as seen in the previous analysis) also have higher physical activity rates. This may be due to:

Confounding Variables: The correlation may not be causal but driven by a third, unmeasured factor. For example, highly urbanized, densely populated areas like Manhattan and Brooklyn tend to have both higher PM2.5 levels (due to traffic and building emissions) and higher rates of active transportation (e.g., walking, cycling) due to necessity and proximity. The high rate of active transportation is counted as "physical activity," artificially inflating the rate in areas with poor air quality.

Aggregation Bias (Ecological Fallacy): The data might be averaged over large regions (like all of "New York City"). The aggregate data may obscure individual behavior. People in polluted areas might still be forced to walk or take public transit, which registers as physical activity, even if they avoid recreational exercise.

Data Source Difference: The physical activity data might come from surveys on overall activity (including work/commuting) rather than leisure-time exercise, and it may not be from the same time period or specific location as the PM2.5 data, introducing bias.`
)}

function _42(md){return(
md`### Question 5

**Are there specific time periods or regions where declining air quality coincides with changes in obesity or activity rates?**`
)}

function _43(md){return(
md`Observations

2012–2014:

Green line dips (AQI improves), then rises again.

Red line (obesity) remains fairly stable.
→ No clear coincidence with obesity change.

2017–2019:

Green line spikes sharply in 2019 (AQI worsens).

Obesity (red line) shows a slight increase but not drastic.
→ Slight correlation may exist: worsening air quality corresponds with a small rise in obesity.

2020–2023:

Green line drops in 2020–2022, then jumps in 2023.

Obesity line remains mostly flat.
→ Again, no strong immediate correlation with obesity changes.

Conclusion

There are no periods with a strong, immediate correlation between declining air quality and obesity.

Slight possible coincidence around 2018–2019: a spike in AQI aligns with a minor increase in obesity.

Physical activity data (if green is AQI) cannot be clearly inferred from this plot; if green represents activity, the fluctuations show inverse trends relative to AQI, suggesting that lower activity coincides with poorer air quality in some years.`
)}

async function _nySeries(stateData,airData)
{
  const abbr = "NY";
  const yearsObj = stateData[abbr] || {};
  const rows = [];

  for (const [yearStr, topics] of Object.entries(yearsObj)) {
    const year = +yearStr;

    // find airData row for New York
    const aqRow = (await airData).find(a => 
      (a.State?.toLowerCase?.().includes("new york") || a.State === "NY") 
      && +a.Year === year
    );

    rows.push({
      state: "NY",
      year,
      obesity: topics.obesity ?? null,
      physical_activity: topics.physical_activity ?? null,
      aqi: aqRow ? (aqRow.MeanAQI ?? aqRow.AQI ?? null) : null
    });
  }

  // sort by year
  return rows.sort((a,b) => a.year - b.year).filter(r => r.aqi !== null || r.obesity !== null);
}


function _45(nySeries,d3,Plot)
{
  // --- prepare time series for NY ---
  const years = Array.from(new Set(nySeries.map(d => d.year))).sort((a,b) => a-b);

  const obesityByYear = years.map(y => {
    const vals = nySeries.filter(d => d.year === y && d.obesity != null).map(d => d.obesity);
    return { year: y, mean: d3.mean(vals) || 0 };
  });

  const activityByYear = years.map(y => {
    const vals = nySeries.filter(d => d.year === y && d.physical_activity != null).map(d => d.physical_activity);
    return { year: y, mean: d3.mean(vals) || 0 };
  });

  const airByYear = years.map(y => {
    const vals = nySeries.filter(d => d.year === y && d.aqi != null).map(d => d.aqi);
    return { year: y, mean: d3.mean(vals) || 0 };
  });

  // --- combine for plotting ---
  const combined = [];
  years.forEach(y => {
    combined.push({ year: y, metric: "Obesity", mean: obesityByYear.find(d=>d.year===y).mean });
    combined.push({ year: y, metric: "Physical Activity", mean: activityByYear.find(d=>d.year===y).mean });
    combined.push({ year: y, metric: "AQI", mean: airByYear.find(d=>d.year===y).mean });
  });

  // --- plot ---
  return Plot.plot({
    width: 800,
    height: 400,
    grid: true,
    y: { label: "Percent / AQI" },
    x: { label: "Year", tickFormat: d3.format("d") },
    marks: [
      Plot.line(combined.filter(d=>d.metric==="Obesity"), { x:"year", y:"mean", stroke:"#d73027", title:d=>`Obesity: ${d.mean.toFixed(2)}%` }),
      Plot.line(combined.filter(d=>d.metric==="Physical Activity"), { x:"year", y:"mean", stroke:"#1a9850", title:d=>`Physical Activity: ${d.mean.toFixed(2)}%` }),
      Plot.line(combined.filter(d=>d.metric==="AQI"), { x:"year", y:"mean", stroke:"#4575b4", title:d=>`AQI: ${d.mean.toFixed(2)}` })
    ],
    color: { legend: true }
  });
}


function _46(md){return(
md`### Question 6

**Can we identify clusters of regions with both high pollution levels and high obesity prevalence using geospatial visualizations?**`
)}

async function _pollutionData2(FileAttachment){return(
(await FileAttachment("pollution.csv").csv()).map(d => ({
  state_id: +d.state_id,
  year: +d.year,
  pollution: +d.pollution
}))
)}

async function _obesityData2(FileAttachment){return(
(await FileAttachment("obesity.csv").csv()).map(d => ({
    state_id: +d.state_id,
    year: +d.year,
    obesity: +d.obesity
  }))
)}

function _yearInput7(Inputs){return(
Inputs.range([2011, 2020], { value: 2015, step: 1, label: "Year" })
)}

function _50(d3,colors)
{
  const positions = [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]]
  
  const len = 40
  const dims = 3 * len
  const margins = 20
  
  const svg = d3.create("svg")
    .attr("width", dims + margins * 2)
    .attr("height", dims + margins * 2)

  svg.append("text")
    .attr("x", dims / 2 + margins)
    .attr("y", dims + margins * 2 - 5)
    .attr("text-anchor", "middle")
    .text("Pollution")

  svg.append("text")
    .attr("x", -dims / 2 - margins)
    .attr("y", margins / 2 + 5)
    .attr("text-anchor", "middle")
    .attr("transform", "rotate(-90)")
    .text("Obesity")
  
  svg.selectAll("rect")
    .data(positions)
    .enter()
      .append("rect")
      .attr("width", len)
      .attr("height", len)
      .attr("x", d => d[1] * len + margins)
      .attr("y", d => (2 - d[0]) * len + margins)
      .attr("fill", d => colors[d[0]][d[1]])
      
  return svg.node()
}


function _51(yearInput7,obesityData2,pollutionData2,d3,topojson,us,colors,tooltip)
{
  const year = yearInput7

  const obesityValues = obesityData2.filter(d => d.year == year && d.obesity).map(d => d.obesity)
  const pollutionValues = pollutionData2.filter(d => d.year == year && d.pollution).map(d => d.pollution)
  
  const width = 1200;
  const height = 600;
  const margins = {top: 50, left: 50, right: 50, bottom: 50};
  
  const svg = d3.create('svg')
    .attr('width', width + margins.left + margins.right)
    .attr('height', height + margins.top + margins.bottom)
    .attr("font-family", "sans-serif")

  const chart = svg.append('g')
    .attr('width', width)
    .attr('height', height)
    .attr('transform', `translate(${margins.left}, ${margins.top})`)
  
  const projection = d3.geoAlbersUsa()
    .scale(1000)
    .translate([480, 300]);
  
  const path = d3.geoPath(projection);
  const states = topojson.feature(us, us.objects.states);

  const scaleX = d3.scaleQuantile()
    .domain(d3.extent(pollutionValues))
    .range([0, 1, 2])

  const scaleY = d3.scaleQuantile()
    .domain(d3.extent(obesityValues))
    .range([0, 1, 2])

  const getStateData = (data, state, year) => data.find(d => d.state_id == state && d.year == year)

  chart.append("g")
    .selectAll("path")
    .data(states.features)
    .enter()
      .append("path")
        .attr("d", path)
        .datum(d => ({
          state: d.properties.name,
          obesity: getStateData(obesityData2, +d.id, year)?.obesity,
          pollution: getStateData(pollutionData2, +d.id, year)?.pollution
        }))
        .attr("fill", d => {
          if (!d.pollution || !d.obesity)
            return "lightgrey"
          const color = colors[scaleY(d.obesity)][scaleX(d.pollution)]
          if (d.state == "New York") {
            console.log(scaleY(d.obesity), scaleX(d.pollution))
            console.log(color)
          }
          return color
          // return color
          // // const country = getCountry(d.properties)
          // // return scale_color(country?.difference) ?? "lightgrey"
         })
        .attr("stroke-width", 1)
        .style("stroke", "#000")
        .on("mouseover", (event, d) => {
          tooltip.style.visibility = "visible";

          const obesity = d.obesity ? d.obesity + "%" : "NA"
          const pollution = d.pollution ? d.pollution + " µg/m³" : "NA"

          tooltip.innerHTML = `
          <p><b>${d.state}</b></p>
          <p>Obesity: ${obesity}</p>
          <p>Pollution: ${pollution}</p>
          `
        })
        .on("mousemove", event => {
          tooltip.style.top = `${event.pageY - 20}px`;
          tooltip.style.left = `${event.pageX + 10}px`;
        })
        .on("mouseout", () => {
          tooltip.style.visibility = "hidden";
        })

  return svg.node()
}


function _colors(){return(
[
    ["#e8e8e8", "#ace4e4", "#5ac8c8"],
    ["#dfb0d6", "#a5add3", "#5698b9"],
    ["#be64ac", "#8c62aa", "#3b4994"]
]
)}

function _53(md){return(
md`Using a bivariate choropleth map we can identify different levels of correlation between obesity and air pollution, because the color scheme encodes two variables simultaneously.

- Darker/deeper purples typically represent high obesity + high pollution.

- Lighter or mixed colors represent lower levels of one or both variables.

**Where the high–high clusters appear**

Looking at the map at different periods in time, the clearest cluster of states showing high pollution and high obesity (the darkest colors) is in the South and parts of the lower Midwest, including states such as:

- Mississippi
- Alabama
- Arkansas
- Louisiana
- Kentucky
- Tennessee
- Missouri
- West Virginia

These states visually form a geographically continuous region.

**Why use this type of visualization**

A bivariate choropleth map is specifically useful for highlighting spatial co-occurrence:

It merges two indicators (pollution & obesity) into one color scheme, so areas where both variables are high stand out distinctly.

Contiguous states with similar shading appear as clusters, making spatial patterns intuitively visible.

Regional grouping in the Southeast and lower Midwest suggests structural or environmental factors that are not randomly distributed.`
)}

function _54(md){return(
md`### Question 8

**How do changes in air quality over time relate to changes in physical activity and obesity rates, when visualized side by side?**`
)}

function _stateInput(stateFIPS,Inputs)
{
  const states = stateFIPS.entries().toArray()
  const input = Inputs.select(states, { label: "State", format: x => x[1], value: states.find(x => x[1] === "NY") })
  return input
}


function _56(d3)
{
  const legend = d3.create("svg")
    .attr("height", 40)
    .attr("font-family", "sans-serif")

  legend.append("rect")
    .attr("width", 35)
    .attr("height", 15)
    .attr("fill", "red")

  legend.append("rect")
    .attr("width", 35)
    .attr("height", 15)
    .attr("y", 25)
    .attr("fill", "steelblue")

  legend.append("text")
    .attr("x", 40)
    .attr("y", 15)
    .text("PM2.5")

  legend.append("text")
    .attr("x", 40)
    .attr("y", 40)
    .text("Obesity")
  
  return legend.node()
}


function _57(stateInput,obesityData2,pollutionData2,d3)
{
  const width = 600
  const height = 500
  const margins = 75

  const [stateId, state] = stateInput
  console.log("state", state)

  const obesityValues = obesityData2.filter(d => d.obesity && d.state_id == stateId && d.year >= 2011 && d.year <= 2020)
  const pollutionValues = pollutionData2.filter(d => d.pollution && d.state_id == stateId && d.year >= 2011 && d.year <= 2020)
  
  const svg = d3.create('svg')
    .attr('width', width + margins * 2)
    .attr('height', height + margins * 2)
    .attr("font-family", "sans-serif")

  const chart = svg.append('g')
    .attr('width', width)
    .attr('height', height)
    .attr('transform', `translate(${margins}, ${margins})`);

  const scaleX = d3.scaleLinear()
    .domain([2011, 2020])
    .range([0, width])

  const scaleY1 = d3.scaleLinear()
    .domain([0, d3.max(obesityData2, d => d.obesity)])
    .range([height, 0])

  const scaleY2 = d3.scaleLinear()
    .domain([0, d3.max(pollutionData2, d => d.pollution)])
    .range([height, 0])

    chart.append("text")
    .attr("x", width / 2)
    .attr("y", - margins.top / 2)
    .attr("text-anchor", "middle")
    .attr("font-weight", 700)
    .attr("color", "white")
    .text("Comparison of obesity rates and pollution over time")

  chart.append("text")
    .attr("x", width / 2)
    .attr("y", height + margins / 2)
    .attr("text-anchor", "middle")
    .text("Year")

  chart.append("text")
    .attr("transform", "rotate(-90)")
    .attr("x", - height / 2)
    .attr("y", - margins / 2)
    .attr("text-anchor", "middle")
    .text("Obesity (%)")
  
  chart.append("text")
    .attr("transform", "rotate(-90)")
    .attr("x", - height / 2)
    .attr("y", width + margins / 2)
    .attr("text-anchor", "middle")
    .text("PM2.5 (µg/m³)")

  chart.append("g")
    .call(d3.axisBottom(scaleX))
    .attr("transform", `translate(0, ${height})`)

  chart.append("g")
    .call(d3.axisLeft(scaleY1))
  
  chart.append("g")
    .call(d3.axisRight(scaleY2))
    .attr("transform", `translate(${width}, 0)`)

  chart.append("path")
    .datum(obesityValues)
    .attr("fill", "none")
    .attr("stroke", "steelblue")
    .attr("stroke-width", 1.5)
    .attr("d", d3.line()
      .x( d => scaleX(d.year))
      .y( d => scaleY1(d.obesity))
    )
  
  chart.append("path")
    .datum(pollutionValues)
    .attr("fill", "none")
    .attr("stroke", "red")
    .attr("stroke-width", 1.5)
    .attr("d", d3.line()
      .x( d => scaleX(d.year))
      .y( d => scaleY2(d.pollution))
    )

  return svg.node()
}


function _58(md){return(
md`For the purposes of this analysis, we will focus on the data for New York specifically, but similar trends can be found across many different states.

**Air quality trend**

From roughly 2011-2020, PM2.5 levels in NY show a general decline, dropping from around ~9 μg/m³ in the early years to roughly 7 μg/m³ later on.
This reflects a gradual improvement in air quality over time.

Notably:

There is a sharp drop around 2015-2016, where PM2.5 decreases more steeply.

After 2016, PM2.5 levels remain relatively lower and stable.

**Obesity trend**

Obesity percentages:

Start in the mid-20% range.

Increase slightly over time, with fluctuations.

Peak around 2014 and 2018, but overall the trend is slow upward movement, not downward.

Even as air quality improves, obesity does not decrease. It instead slowly rises.

**Relationship Between Pollution and Obesity**

When visualized side by side:

Air quality improves, but obesity doesn’t improve with it.

This suggests:

- There is no clear inverse relationship in the visualization.

- Lower PM2.5 does not correspond to lower obesity rates over this time span.

- If anything, obesity continues on its own trend, seemingly unaffected by changes in PM2.5.`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["Nutrition__Physical_Activity__and_Obesity_-_Behavioral_Risk_Factor_Surveillance_System.csv", {url: new URL("./files/760e423b97310942fed91b520fb2442a4beed5e85f84b54950e9c889ce429d105f5a04d09ed93c73e5367e118a9bf272becaf3560bd27cf7eca3a1792035ba13.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["Air_Quality.csv", {url: new URL("./files/0a9fffe01f039b2a78ad31d3a73b2d30009fbe755cf96468c853e9662d3cf5547d4533ed907f25e4052caa343b1ab8f111e9aff8a7af90cbd63cc6add88d84c1.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["pollution.csv", {url: new URL("./files/e024916c7bada3953af29be82d022cbffe29a3a4f9e66e9556206413df51159e52b521d1667930834a679042fa875557a3206a73853b0aeddc19411412b4a397.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["obesity.csv", {url: new URL("./files/9d90acdd14e6d5dec0c9c0f4459fb39103bad7607a6e2c578a854eccec07f42436bba327bac17c10a05f3717e9c3d96f5f4a36c1c7e180522c85ff6f6af12733.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("topojson")).define("topojson", ["require"], _topojson);
  main.variable(observer()).define(["FileAttachment"], _4);
  main.variable(observer("obesityData")).define("obesityData", ["FileAttachment"], _obesityData);
  main.variable(observer()).define(["obesityData"], _6);
  main.variable(observer()).define(["FileAttachment"], _7);
  main.variable(observer("airData")).define("airData", ["FileAttachment"], _airData);
  main.variable(observer()).define(["airData"], _9);
  main.variable(observer("us")).define("us", ["d3"], _us);
  main.variable(observer()).define(["topojson","us"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("stateData")).define("stateData", ["obesityData","d3"], _stateData);
  main.variable(observer("stateFIPS")).define("stateFIPS", _stateFIPS);
  main.variable(observer()).define(["stateData"], _15);
  main.variable(observer()).define(["stateData"], _16);
  main.variable(observer()).define(["stateData"], _17);
  main.variable(observer()).define(["stateData"], _18);
  main.variable(observer()).define(["md"], _19);
  main.variable(observer("colorScale")).define("colorScale", ["d3","stateData"], _colorScale);
  main.variable(observer("legend")).define("legend", ["d3","colorScale"], _legend);
  main.variable(observer("tooltip")).define("tooltip", _tooltip);
  main.variable(observer("viewof year")).define("viewof year", ["html"], _year);
  main.variable(observer("year")).define("year", ["Generators", "viewof year"], (G, _) => G.input(_));
  main.variable(observer("viewof metric")).define("viewof metric", ["html"], _metric);
  main.variable(observer("metric")).define("metric", ["Generators", "viewof metric"], (G, _) => G.input(_));
  main.variable(observer("map")).define("map", ["d3","metric","year","stateData","topojson","us","stateFIPS","tooltip"], _map);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer()).define(["md"], _27);
  main.variable(observer("airQuality")).define("airQuality", ["FileAttachment"], _airQuality);
  main.variable(observer("airQualityData")).define("airQualityData", ["d3","airQuality"], _airQualityData);
  main.variable(observer("viewof region")).define("viewof region", ["html","airQualityData"], _region);
  main.variable(observer("region")).define("region", ["Generators", "viewof region"], (G, _) => G.input(_));
  main.variable(observer("lineChart")).define("lineChart", ["d3","airQualityData","region"], _lineChart);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer()).define(["md"], _33);
  main.variable(observer()).define(["airQualityData"], _34);
  main.variable(observer()).define(["obesityData"], _35);
  main.variable(observer()).define(["airQualityData"], _36);
  main.variable(observer("regressionLinear")).define("regressionLinear", ["require"], _regressionLinear);
  main.variable(observer()).define(["regressionLinear"], _38);
  main.variable(observer("viewof region1")).define("viewof region1", ["Inputs","airQualityData"], _region1);
  main.variable(observer("region1")).define("region1", ["Generators", "viewof region1"], (G, _) => G.input(_));
  main.variable(observer("scatterPlot")).define("scatterPlot", ["airQualityData","region1","obesityData","d3","tooltip"], _scatterPlot);
  main.variable(observer()).define(["md"], _41);
  main.variable(observer()).define(["md"], _42);
  main.variable(observer()).define(["md"], _43);
  main.variable(observer("nySeries")).define("nySeries", ["stateData","airData"], _nySeries);
  main.variable(observer()).define(["nySeries","d3","Plot"], _45);
  main.variable(observer()).define(["md"], _46);
  main.variable(observer("pollutionData2")).define("pollutionData2", ["FileAttachment"], _pollutionData2);
  main.variable(observer("obesityData2")).define("obesityData2", ["FileAttachment"], _obesityData2);
  main.variable(observer("viewof yearInput7")).define("viewof yearInput7", ["Inputs"], _yearInput7);
  main.variable(observer("yearInput7")).define("yearInput7", ["Generators", "viewof yearInput7"], (G, _) => G.input(_));
  main.variable(observer()).define(["d3","colors"], _50);
  main.variable(observer()).define(["yearInput7","obesityData2","pollutionData2","d3","topojson","us","colors","tooltip"], _51);
  main.variable(observer("colors")).define("colors", _colors);
  main.variable(observer()).define(["md"], _53);
  main.variable(observer()).define(["md"], _54);
  main.variable(observer("viewof stateInput")).define("viewof stateInput", ["stateFIPS","Inputs"], _stateInput);
  main.variable(observer("stateInput")).define("stateInput", ["Generators", "viewof stateInput"], (G, _) => G.input(_));
  main.variable(observer()).define(["d3"], _56);
  main.variable(observer()).define(["stateInput","obesityData2","pollutionData2","d3"], _57);
  main.variable(observer()).define(["md"], _58);
  return main;
}
